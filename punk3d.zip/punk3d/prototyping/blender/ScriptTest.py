import bpy

# le premier truc dont j'ai besoin c'est d'un afficheur de polygones

# displayer shader

name="MyMaterial"
overwrite=True

if(overwrite is True) and ( name in bpy.data.materials ):
    blenderMat = bpy.data.materials[name]

else:
    blenderMat = bpy.data.materials.new(name)
    name = blenderMat.name

    # get the nodes
blenderMat.use_nodes=True
nodes = blenderMat.node_tree.nodes
    # clear all nodes to start clean
for node in nodes:
    nodes.remove(node)
    # link nodes
links = blenderMat.node_tree.links

    #create the basic material nodes
node_output  = nodes.new(type='ShaderNodeOutputMaterial')
node_output.location = 400,0
node_pbsdf    = nodes.new(type='ShaderNodeBsdfPrincipled')
node_pbsdf.location = 0,0
node_pbsdf.inputs['Base Color'].default_value = (0.8, 0.05, 0.05, 1.0)
node_pbsdf.inputs['Alpha'].default_value = 1 # 1 is opaque, 0 is invisible
node_pbsdf.inputs['Roughness'].default_value = 0.2
node_pbsdf.inputs['Specular'].default_value = 0.5
node_pbsdf.inputs['Transmission'].default_value = 0.5 # 1 is fully transparent

link = links.new(node_pbsdf.outputs['BSDF'], node_output.inputs['Surface'])

blenderMat.blend_method = 'HASHED'
blenderMat.shadow_method = 'HASHED'
blenderMat.use_screen_refraction = True

bpy.context.scene.eevee.use_ssr = True
bpy.context.scene.eevee.use_ssr_refraction = True

print( blenderMat )



# make mesh
vertices = [ (-1, -1, 0), ( 1, -1, 0), ( 1,  1, 0), (-1,  1, 0) ]
edges = []
faces = [ [0,1,2,3] ]

if 'new_mesh' in bpy.data.meshes : 
    bpy.data.meshes.remove( bpy.data.meshes['new_mesh'] )

new_mesh = bpy.data.meshes.new('new_mesh')  
print ( 'create mesh: ' + str( new_mesh ) )           

new_mesh.from_pydata(vertices, edges, faces)
new_mesh.update()
# make object from mesh
new_object = bpy.data.objects.new('new_object', new_mesh)

for mesh in bpy.data.meshes :
    print( mesh )


# Assign material to object
if new_object.data.materials:
    # assign to 1st material slot
    new_object.data.materials[0] = blenderMat
else:
    # no slots
    new_object.data.materials.append(blenderMat)
    
print( new_object.data.materials[0] )


# make collection
new_collection = bpy.data.collections.new('new_collection')
bpy.context.scene.collection.children.link(new_collection)
# add object to scene collection
new_collection.objects.link(new_object)