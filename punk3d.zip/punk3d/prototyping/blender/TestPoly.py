# api imports

import bpy
import sys
import os
import imp
import mathutils
from math import *

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )
    
sys.path.append( DIR + "/punkMap/src/display" )

import Tracer
imp.reload( Tracer )
from Tracer import *

sys.path.append( DIR + "/punkMap/src/maths" )

import PolyOp
imp.reload( PolyOp )
from PolyOp import *

import BSP
imp.reload( BSP )
from BSP import *

# tests

V = mathutils.Vector

test1 = Tracer()
test2 = Tracer()

print( PolyOp.PolyFromPlane )

poly = PolyOp.PolyFromPlane( V(( 0, 0, 0)), V(( 1, 1, 1)), 10 )

test1.addPoly( poly )
test1.draw( (1,1,0,.125) )


poly = PolyOp.SquareFromPlane( V(( 0, 0, 0)), V(( 1, 0, 1)), 2 )

polys = PolyOp.SplitConvex( V(( 0, 0, 0)), V(( 0, 0, 1)), poly )

test2.addPoly( polys[0] )
test2.addPoly( polys[1] )

test2.draw( (1,0,0,.5) )

del test1
del test2