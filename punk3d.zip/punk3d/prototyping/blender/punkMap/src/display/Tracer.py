import bpy
import mathutils
from math import *
    
class Tracer:

    # -------------------------------------------------------------------------
    # static props
    # -------------------------------------------------------------------------
    
    _NUM_INSTANCES = 0
    
    # -------------------------------------------------------------------------
    # static methods
    # -------------------------------------------------------------------------
    
    # private ------------------------------
    
    def __DeleteMesh ( mesh: object ):
    
        try:
            mesh.user_clear()
            can_continue = True
        except:
            can_continue = False
    
        if can_continue == True:
            try:
                bpy.data.meshes.remove(mesh)
                result = True
            except:
                result = False
        else:
            result = False
        
        return result


    # -------------------------------------------------------------------------
    # instance props
    # -------------------------------------------------------------------------

    def __init__( self ):
        
        # private ---------------------------------------
        
        self._name = "Tracer_" + str( Tracer._NUM_INSTANCES )
        Tracer._NUM_INSTANCES += 1
        
        self._verts = []
        self._faces = []
        
        print( "Instanciate " + self._name )
        
        
    def __del__( self ):
        
        del self._faces
        del self._verts
        
        print( "Delete " + self._name )
        del self._name


    # -------------------------------------------------------------------------
    # instance methods
    # -------------------------------------------------------------------------

    # public ------------------------------
    
    def addPoly( self, verts: list ):
        
        if len( verts ) == 0 :
            return
        
        face = []
        
        for vert in verts :            
            face.append( len( self._verts ) )
            self._verts.append( vert )
            
        self._faces.append( face )
        
    
    def draw( self, color: tuple ):
        
        # objects names
        
        meshName = self._name + "_mesh"
        objName = self._name + "_obj"
        collName = self._name + "_coll"
        matName = self._name + "_mat"
        
        # delete objects if needed

        if collName in bpy.data.collections:
            coll = bpy.data.collections[ collName ]
            for obj in coll.objects:
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove( coll )
    
        if objName in bpy.data.objects:
            bpy.data.objects[ objName ].delete()

        if meshName in bpy.data.meshes:
            Tracer.__DeleteMesh( bpy.data.meshes[ meshName ] )    

        # do not create objects if geometry empty

        if len( self._verts ) == 0 :
            return

        # create mesh

        tracer = bpy.data.meshes.new( meshName )
        tracer.from_pydata( self._verts, [], self._faces )
        tracer.update()

        # create object & collection

        tracerObj = bpy.data.objects.new( objName, tracer )
        tracerColl = bpy.data.collections.new( collName )
        bpy.context.scene.collection.children.link( tracerColl )
        tracerColl.objects.link( tracerObj )        
        
        # create material if not exists

        if not matName in bpy.data.materials:
            bpy.data.materials.new( name = matName )
    
        mat = bpy.data.materials[ matName ]
        mat.diffuse_color = color
        tracerObj.data.materials.append( mat )