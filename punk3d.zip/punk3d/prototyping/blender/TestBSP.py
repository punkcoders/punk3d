# api imports

import bpy
import sys
import os
import imp
import mathutils
from math import *
import gc
import time

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )
    
sys.path.append( DIR + "/punkMap/src/display" )

import Tracer
imp.reload( Tracer )
from Tracer import *

import GeomExtract
imp.reload( GeomExtract )
from GeomExtract import *

sys.path.append( DIR + "/punkMap/src/maths" )

import PolyOp
imp.reload( PolyOp )
from PolyOp import * 

import BSP
imp.reload( BSP )
from BSP import *

import BSP_Poly
imp.reload( BSP_Poly )
from BSP_Poly import *


# tests

gc.enable()
gc.collect()

V = mathutils.Vector

# start with a stupid face list
# the first problem is the detection of holes
# brushes are an optimization

print("EXTRACT GEOMETRY")

faceList = []
bbox = [[0,0,0],[0,0,0]]

for obj in bpy.context.selected_objects:    
    
    if obj.type == "MESH" :
    
        mat = obj.matrix_world
        polys = obj.data.polygons
        vertList = obj.data.vertices
        
        for f in polys:
        
            iverts = f.vertices
            face = []
        
            for iv in iverts:
                face.append( mat @ vertList[iv].co )
           
            faceList.append( face ) 
        
    
        for vert in vertList:
        
            v = mat @ vert.co
        
            for dim in [0,1,2] :
                if v[dim] < bbox[0][dim]:
                    bbox[0][dim] = v[dim]
                if v[dim] > bbox[1][dim]:
                    bbox[1][dim] = v[dim]
                
        
print( "BOUNDING BOX: " + str( bbox ) )


# BUILD NODES

print("Build BSP nodes")

BSP_Builder.BuildNodesFromFaces( faceList )

print( str( len( BSP.NODES ) ) + " nodes")

#for node in BSP.NODES:
    #print( node )


# BUILD LEAVES

print("Build BSP leaves")

BSP_Builder.BuildLeaves()

print( str( len( BSP.LEAVES ) ) + " leaves")


# DISPLAY NODES

print("DISPLAY NODES")

maxSize = 0
for xyz in bbox:
    for val in xyz:
        absv = abs( val )
        if absv > maxSize:
            maxSize = absv

tracer1 = Tracer()
for iNode in range( 0, len(BSP.NODES) ):    
    poly = BSP_Poly.DoNodeFace( iNode, maxSize*2 )
    tracer1.addPoly( poly )
tracer1.draw( (0,0,1,0.125) )


# END

del BSP.PLANES
del BSP.NODES

gc.collect()

print("end")