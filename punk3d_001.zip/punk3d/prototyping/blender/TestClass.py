class Client:
    
    #static props
    
    CLIENT = "Client"
    
    #static methods
    
    def StatMethod():
        print("stat method called")
    
    #instance props
    
    def __init__(self,nom,prenom):
        self.nom, self.prenom = nom, prenom
        
    #methods
        
    def toString(self):
        return ( Client.CLIENT+" "+self.nom+" "+self.prenom )
    

#test class
    
Client.StatMethod()
obj = Client("Charles","AUGEARD")
print( obj.toString() )