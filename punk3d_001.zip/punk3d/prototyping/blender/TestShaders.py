import bpy

matName = "TestMat"


# create material if not exists

if not matName in bpy.data.materials:
    print("material doesn't exist")
    bpy.data.materials.new(name=matName)
else:
    print("material exists")
    
mat = bpy.data.materials[ matName ]

print( "material: " + str( mat ) )


# make material transparent color
    
mat.diffuse_color = ( 1.0, 1.0, 0.0, 0.1 )


# apply material on objects

for obj in bpy.context.selected_objects:
    obj.data.materials[0] = mat