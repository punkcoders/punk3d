import mathutils
from math import *

# aide-mémoire

def DistPointPlane( point, center, normal ):
    return ( point - center ) @ normal


vA = mathutils.Vector( (1,1,1) )
vB = mathutils.Vector( (0,0,10) )

pC = mathutils.Vector( (0,0,0) )
pN = mathutils.Vector( (0,0,1) )

print( vA + vB )

print( vA * 10 )

print( vA * vB )

print( vA @ vB )

print( vA.dot( vB ) )

print( vA.cross( vB ) )

isec_l_p = mathutils.geometry.intersect_line_plane
sec = isec_l_p( vA, vB, pC, pN, False )
print( "isec: " + str( sec ) )

print( DistPointPlane( vA, pC, pN ) )