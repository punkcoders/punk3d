import bpy
import sys
import os
import imp

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )

sys.path.append( DIR + "/punkMap/src/display" )

import ConvexExtractor
imp.reload( ConvexExtractor )
from ConvexExtractor import *

import Tracer
imp.reload( Tracer )
from Tracer import *

sys.path.append( DIR + "/punkMap/src/maths" )

import Convex
imp.reload( Convex )
from Convex import *

import PolyOp
imp.reload( PolyOp )
from PolyOp import *

sys.path.append( DIR + "/punkMap/src/files" )

import ConvexFile
imp.reload( ConvexFile )
from ConvexFile import *


# tests

validScene = ConvexExtractor.MeshesAreConvex( 0.0001 )

if validScene:
    
    print( "SCENE IS VALID FOR EXPORT" )
    
    # build convex data
    
    convexes = ConvexExtractor.ConvertSceneToConvex()
    ConvexManager.BuildConvexes( convexes, 0.0001 )
       
    print( "CONVEX DATA BUILT" )
        
    # save convex data
    
    ConvexFile.Write()
        
    # test read convex data
    
    ConvexFile.Read()  
        
    # for convex in CVX.CONVEXES :
        # print( convex )
        
    # for plane in CVX.PLANES : 
        # print( plane )
        
    # for face in CVX.FACES :
        # print( face )
        
    # print( CVX.VERTS )
        
    
    # show faces
    
    tr = Tracer()        
    for face in CVX.FACES :            
        tr.addPoly( face.getVerts() )
    tr.draw( (0,0,1,.25) )
    
    # show planes
    
    tr2 = Tracer()
    for plane in CVX.PLANES :        
        verts = PolyOp.PolyFromPlane( plane.getCenter(), plane.getNormal(), 8 )
        tr2.addPoly( verts )
    tr2.draw( (1,1,0,.1) )
        
    
    
else:
    
    print( "CANNOT EXPORT SCENE" )