import bpy
import sys
import os
import imp

dir = os.path.dirname(bpy.data.filepath)
if not dir in sys.path:
    sys.path.append(dir)

# my imports

print(dir)

sys.path.append(dir+"/punkMap/src/display")

import Tracer
imp.reload(Tracer)

print( Tracer )