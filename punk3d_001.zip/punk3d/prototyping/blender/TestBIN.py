import bpy
import sys
import os
import imp
import struct

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir ) 
    
# test

fn = bpy.data.filepath + ".bin"

with open( fn, "wb") as f:
    
    mess = 'CONVEX DATA FILE, version 0.0'
    while len(mess)<255 :
        mess += " "
    s = bytes( mess, 'utf-8' )
    f.write( struct.pack( "<256s" , s ) )
    
    f.write( struct.pack( "<L", 1000 ) )
    
with open( fn, "rb") as f:
    
    data = struct.unpack( "<256s" , f.read(256) )[0]
    print( data.decode('utf-8') )
    
    print( struct.unpack( "<L", f.read(4) )[0] )
    
    