import struct
import bpy
import sys
import os
import imp
import mathutils
from math import *

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )
    
sys.path.append( DIR + "/punkMap/src/maths" )

import Convex
imp.reload( Convex )
from Convex import *


# CLASS WRITER / READER

class ConvexFile :
    
    # write CVX content in file
    
    def Write() :
        
        baseName = ( bpy.path.basename(bpy.context.blend_data.filepath) ).split(".")[0]
        path = DIR + "\\" + baseName + ".cvx"    
        print( "SAVE TO " + path )
        
        with open( path, "wb") as f:
            
            # HEADER ------------------------------------------------

            # 256 bytes: a null-terminated string with format version

            # uint32: num convexes
            # uint32: num planes
            # uint32: num faces
            # uint32: num verts
            # uint32: num planefaces indexes
            # uint32: num faceverts indexes            
    
            mess = 'CONVEX SOLIDS, version 0.0.1'
            while len(mess)<255 :
                mess += " "
            s = bytes( mess, 'utf-8' )
            f.write( struct.pack( "<256s" , s ) )
            
            f.write( struct.pack( "<L" , len( CVX.CONVEXES ) ) )
            f.write( struct.pack( "<L" , len( CVX.PLANES ) ) )
            f.write( struct.pack( "<L" , len( CVX.FACES ) ) )
            f.write( struct.pack( "<L" , len( CVX.VERTS ) ) )
            
            planeFaces = []            
            for plane in CVX.PLANES :
                iFaces = plane.getFaceIndexes()
                for i in iFaces :
                    planeFaces.append( i )
                    
            f.write( struct.pack( "<L" , len( planeFaces ) ) )
                        
            faceVerts = []
            for face in CVX.FACES :
                iVerts = face.getVertsIndexes()
                for i in iVerts :
                    faceVerts.append( i )
                    
            f.write( struct.pack( "<L" , len( faceVerts ) ) )
            
                        
            # STRUCT CONVEX -----------------------------------------

            # uint32: first face
            # uint32: num faces
            # uint32: flags A
            # uint32: flags B            
            
            for convex in CVX.CONVEXES :
                
                f.write( struct.pack( "<L" , convex.getFirstFace() ) )
                f.write( struct.pack( "<L" , convex.getNumFaces() ) )
                f.write( struct.pack( "<L" , int( convex.getOccluder() ) ) )
                f.write( struct.pack( "<L" , 0 ) )
            
            
            # STRUCT PLANE -------------------------------------------

            # 4 x float64: normal, offset
            # uint32: firstFace
            # uint32: numFaces
            
            firstFace = 0
            for plane in CVX.PLANES :
                
                normal = plane.getNormal()
                f.write( struct.pack( "<d" , normal[0] ) )
                f.write( struct.pack( "<d" , normal[1] ) )
                f.write( struct.pack( "<d" , normal[2] ) )
                f.write( struct.pack( "<d" , plane.getOffset() ) )
                
                iFaces = plane.getFaceIndexes()
                f.write( struct.pack( "<L" , firstFace ) )
                f.write( struct.pack( "<L" , len(iFaces) ) )
                firstFace += len(iFaces)
                
                
            # STRUCT FACE -------------------------------------------

            # uint32: firstVert
            # uint32: numVerts
            # uint32: index plane
            # uint32: flags
            
            firstVert = 0
            for face in CVX.FACES :
                
                ips = face.getVertsIndexes()
                f.write( struct.pack( "<L" , firstVert ) )
                f.write( struct.pack( "<L" , len(ips) ) )
                firstVert += len(ips)
            
                f.write( struct.pack( "<L" , face.getPlane() ) )
                f.write( struct.pack( "<L" , 0 ) )
                
                
            # STRUCT VERT -------------------------------------------

            # 3 x float64: x, y, z
            
            for vert in CVX.VERTS :
                                
                f.write( struct.pack( "<d" , vert[0] ) )
                f.write( struct.pack( "<d" , vert[1] ) )
                f.write( struct.pack( "<d" , vert[2] ) )
                
                
            # STRUCT PLANE FACE INDEX -------------------------------

            # uint32: faceIndex
            
            for i in planeFaces:
                f.write( struct.pack( "<L" , i ) )
                
                
            # STRUCT FACE VERT INDEX --------------------------------

            # uint32: vertIndex
            
            for i in faceVerts:
                f.write( struct.pack( "<L" , i ) )
                
                
            # end
        
            return True
    
        return False
    
    

    # fill CVX content from file
    # this reader is just used for tests
    
    def Read() :
        
        CVX.CONVEXES = []
        CVX.PLANES = []
        CVX.FACES = []
        CVX.VERTS = []
        
        baseName = ( bpy.path.basename(bpy.context.blend_data.filepath) ).split(".")[0]
        path = DIR + "\\" + baseName + ".cvx"
        print( "OPEN " + path )      
        
        with open( path, "rb") as f:
            
            # HEADER ------------------------------------------------

            # 256 bytes: a null-terminated string with format version

            # uint32: num convexes
            # uint32: num planes
            # uint32: num faces
            # uint32: num verts
            # uint32: num planefaces indexes
            # uint32: num faceverts indexes
            
    
            b = struct.unpack( "<256s" , f.read(256) )[0]
            print( b.decode('utf-8') )
            
            lengths = struct.unpack( "<6L" , f.read(6*4) )            
            numConvexes = lengths[0]
            numPlanes = lengths[1]
            numFaces = lengths[2]
            numVerts = lengths[3]
            numPlaneFaces = lengths[4] # not sure we need this
            numFaceVerts = lengths[5]
            
            
            # STRUCT CONVEX -----------------------------------------

            # uint32: first face
            # uint32: num faces
            # uint32: flags A
            # uint32: flags B
            
            while len( CVX.CONVEXES ) < numConvexes :
                
                res = struct.unpack( "<4L" , f.read(4*4) )                
                convex = Convex( res[0], res[1], res[2] )                
                CVX.CONVEXES.append( convex )
                
                
            # STRUCT PLANE ------------------------------------------

            # 4 x float64: normal, offset
            # uint32: firstFace
            # uint32: numFaces
            
            #planesFirstFace = []
            planesNumFaces = []
            
            while len( CVX.PLANES ) < numPlanes :
                
                res = struct.unpack( "<4d" , f.read(4*8) )
                normal = mathutils.Vector( ( res[0], res[1], res[2] ) )
                offset = res[3]
                
                #planesFirstFace.append( struct.unpack( "<L" , f.read(4) )[0] )
                struct.unpack( "<L" , f.read(4) )[0]
                
                planesNumFaces.append( struct.unpack( "<L" , f.read(4) )[0] )
                
                plane = ConvexPlane( normal, offset, [] )
                CVX.PLANES.append( plane )
                
                
            # STRUCT FACE -------------------------------------------

            # uint32: firstVert
            # uint32: numVerts
            # uint32: index plane
            # uint32: flags
            
            #facesFirstVert = []
            facesNumVerts = []
            
            while len( CVX.FACES ) < numFaces :
                
                res = struct.unpack( "<4L" , f.read(4*4) )
                
                #facesFirstVert.append( res[0] )
                facesNumVerts.append( res[1] )
                
                face = ConvexFace( [] )
                face.setPlane( res[2] )
                CVX.FACES.append( face )


            # STRUCT VERT -------------------------------------------

            # 3 x float64: x, y, z
            
            while len( CVX.VERTS ) < numVerts :
                
                res = struct.unpack( "<3d" , f.read(3*8) )
                vert = mathutils.Vector( (res[0],res[1],res[2]) ) # je crois qu'on peut replace par tuple
                CVX.VERTS.append( vert )                
                
            
            # STRUCT PLANE FACE INDEX -------------------------------

            # uint32: faceIndex
            
            iP = 0
            while iP < numPlanes :
                
                plane = CVX.PLANES[ iP ]
                numPlaneFaces = planesNumFaces[ iP ]
                
                iF = 0
                while iF < numPlaneFaces :
                    plane.addFace( struct.unpack( "<L" , f.read(4) )[0] )
                    iF += 1
                
                iP += 1
                
            
            # STRUCT FACE VERT INDEX --------------------------------

            # uint32: vertIndex
            
            iF = 0
            while iF < numFaces :
                
                face = CVX.FACES[ iF ]
                numFaceVerts = facesNumVerts[ iF ]
                
                iV = 0
                while iV < numFaceVerts :
                    face.addVert( struct.unpack( "<L" , f.read(4) )[0] )
                    iV += 1
                
                iF += 1
            
            
            # end
        
            return True
        
        return False
    
    
    # fill BSP content from file
    # ( ? ) don't know if i'll do this... see tomorrow
    
    def ReadInBSP():
        pass