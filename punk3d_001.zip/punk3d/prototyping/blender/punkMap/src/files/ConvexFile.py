import struct
import bpy
import sys
import os
import imp
import mathutils
from math import *

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )
    
sys.path.append( DIR + "/punkMap/src/maths" )

import Convex
imp.reload( Convex )
from Convex import *


# CLASS WRITER / READER

class ConvexFile :
    
    # write CVX content in file
    
    def Write() :
        
        baseName = ( bpy.path.basename(bpy.context.blend_data.filepath) ).split(".")[0]
        path = DIR + "\\" + baseName + ".cvx"    
        print( "SAVE TO " + path )
        
        with open( path, "wb") as f:
            
            # HEADER ------------------------------------------------

            # 256 bytes: a null-terminated string with format version

            # uint32: num convexes
            # uint32: num planes
            # uint32: num faces
            # uint32: num verts          
    
            mess = 'CONVEX SOLIDS, version 0.0.2'
            while len(mess)<255 :
                mess += " "
            s = bytes( mess, 'utf-8' )
            f.write( struct.pack( "<256s" , s ) )
            
            f.write( struct.pack( "<L" , len( CVX.CONVEXES ) ) )
            f.write( struct.pack( "<L" , len( CVX.PLANES ) ) )
            f.write( struct.pack( "<L" , len( CVX.FACES ) ) )
            f.write( struct.pack( "<L" , len( CVX.VERTS ) ) )
                       
                        
            # STRUCT CONVEX -----------------------------------------

            # uint32: num faces
            # uint32: flags A          
            
            for convex in CVX.CONVEXES :
                
                f.write( struct.pack( "<L" , convex.getNumFaces() ) )
                f.write( struct.pack( "<L" , int( convex.getOccluder() ) ) )
            
            
            # STRUCT PLANE -------------------------------------------

            # 4 x float64: normal, offset
            # uint32: numFaces
            # uint32: flags
            
            for plane in CVX.PLANES :
                
                normal = plane.getNormal()
                f.write( struct.pack( "<d" , normal[0] ) )
                f.write( struct.pack( "<d" , normal[1] ) )
                f.write( struct.pack( "<d" , normal[2] ) )
                f.write( struct.pack( "<d" , plane.getOffset() ) )
                f.write( struct.pack( "<L" , len(plane.getFaceIndexes()) ) )
                f.write( struct.pack( "<L" , 0 ) )
                
                
            # STRUCT FACE -------------------------------------------

            # uint32: numVerts
            # uint32: index plane
            
            for face in CVX.FACES :
                
                f.write( struct.pack( "<L" , len(face.getVertsIndexes()) ) )            
                f.write( struct.pack( "<L" , face.getPlane() ) )
                
                
            # STRUCT VERT -------------------------------------------

            # 3 x float64: x, y, z
            
            for vert in CVX.VERTS :
                                
                f.write( struct.pack( "<d" , vert[0] ) )
                f.write( struct.pack( "<d" , vert[1] ) )
                f.write( struct.pack( "<d" , vert[2] ) )
                
                
            # STRUCT PLANE FACE INDEX -------------------------------

            # uint32: faceIndex
                        
            for plane in CVX.PLANES :
                iFaces = plane.getFaceIndexes()
                for i in iFaces :
                    f.write( struct.pack( "<L" , i ) )                
                
                
            # STRUCT FACE VERT INDEX --------------------------------

            # uint32: vertIndex
            
            for face in CVX.FACES :
                iVerts = face.getVertsIndexes()
                for i in iVerts :
                    f.write( struct.pack( "<L" , i ) ) 
                                    
                
            # end
        
            return True
    
        return False
    
    

    # fill CVX content from file
    # this reader is just used for tests
    
    def Read() :
        
        CVX.CONVEXES = []
        CVX.PLANES = []
        CVX.FACES = []
        CVX.VERTS = []
        
        baseName = ( bpy.path.basename(bpy.context.blend_data.filepath) ).split(".")[0]
        path = DIR + "\\" + baseName + ".cvx"
        print( "OPEN " + path )      
        
        with open( path, "rb") as f:
            
            # HEADER ------------------------------------------------

            # 256 bytes: a null-terminated string with format version

            # uint32: num convexes
            # uint32: num planes
            # uint32: num faces
            # uint32: num verts
            # uint32: num planefaces indexes
            # uint32: num faceverts indexes
            
    
            b = struct.unpack( "<256s" , f.read(256) )[0]
            print( b.decode('utf-8') )
            
            lengths = struct.unpack( "<4L" , f.read(4*4) )            
            numConvexes = lengths[0]
            numPlanes = lengths[1]
            numFaces = lengths[2]
            numVerts = lengths[3]
            
            
            # STRUCT CONVEX -----------------------------------------

            # uint32: num faces
            # uint32: flags A
            
            firstFace = 0
            while len( CVX.CONVEXES ) < numConvexes :
                
                res = struct.unpack( "<2L" , f.read(2*4) )                
                convex = Convex( firstFace, res[0], res[1] )                
                CVX.CONVEXES.append( convex )
                
                firstFace += res[0]
                
                
            # STRUCT PLANE ------------------------------------------

            # 4 x float64: normal, offset
            # uint32: numFaces
            # uint32: flags
            
            planesNumFaces = []
            
            while len( CVX.PLANES ) < numPlanes :
                
                res = struct.unpack( "<4d" , f.read(4*8) )
                normal = mathutils.Vector( ( res[0], res[1], res[2] ) )
                offset = res[3]
                
                res = struct.unpack( "<2L" , f.read(2*4) )                
                planesNumFaces.append( res[0] )
                
                plane = ConvexPlane( normal, offset, [] )
                CVX.PLANES.append( plane )
                
                
            # STRUCT FACE -------------------------------------------

            # uint32: numVerts
            # uint32: index plane
            
            facesNumVerts = []
            
            while len( CVX.FACES ) < numFaces :
                
                res = struct.unpack( "<2L" , f.read(2*4) )                
                facesNumVerts.append( res[0] )                
                face = ConvexFace( [] )
                face.setPlane( res[1] )
                CVX.FACES.append( face )


            # STRUCT VERT -------------------------------------------

            # 3 x float64: x, y, z
            
            while len( CVX.VERTS ) < numVerts :
                
                res = struct.unpack( "<3d" , f.read(3*8) )
                vert = mathutils.Vector( (res[0],res[1],res[2]) ) # je crois qu'on peut replace par tuple
                CVX.VERTS.append( vert )                
                
            
            # STRUCT PLANE FACE INDEX -------------------------------

            # uint32: faceIndex
            
            iP = 0
            while iP < numPlanes :
                
                plane = CVX.PLANES[ iP ]
                numPlaneFaces = planesNumFaces[ iP ]
                
                iF = 0
                while iF < numPlaneFaces :
                    plane.addFace( struct.unpack( "<L" , f.read(4) )[0] )
                    iF += 1
                
                iP += 1
                
            
            # STRUCT FACE VERT INDEX --------------------------------

            # uint32: vertIndex
            
            iF = 0
            while iF < numFaces :
                
                face = CVX.FACES[ iF ]
                numFaceVerts = facesNumVerts[ iF ]
                
                iV = 0
                while iV < numFaceVerts :
                    face.addVert( struct.unpack( "<L" , f.read(4) )[0] )
                    iV += 1
                
                iF += 1
            
            
            # end
        
            return True
        
        return False
    
    
    # fill BSP content from file
    # ( ? ) don't know if i'll do this... see tomorrow
    
    def ReadInBSP():
        pass