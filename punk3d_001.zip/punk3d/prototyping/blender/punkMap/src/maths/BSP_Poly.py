# api imports

import bpy
import sys
import os
import imp
import mathutils
from math import *
import gc
import time

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )

sys.path.append( DIR + "/punkMap/src/maths" )

import PolyOp
imp.reload( PolyOp )
from PolyOp import *

import BSP
imp.reload( BSP )
from BSP import *


# ----------------------------------------------------------------
# STATIC CLASS FOR BSP POLYGONS GENERATOR ------------------------
# ----------------------------------------------------------------

class BSP_Poly:
    
    # generate node faces
    
    def DoNodeFace( iNode, size )->list:
        
        node = BSP.NODES[ iNode ]
        plane = BSP.PLANES[ node.getPlaneIndex() ]
        
        # make a cropped-bbox poly
        
        poly = PolyOp.PolyFromPlane( plane.getCenter(), plane.getNormal(), size )
        
        # clip by parent chain
        
        iParent = node.getParentIndex()
        
        while iParent >-1 :
            
            parentNode = BSP.NODES[iParent]
            parentPlane = BSP.PLANES[parentNode.getPlaneIndex()]
            
            side = -1
            if node.isFrontOfPArent():
                side = 1
                
            poly = PolyOp.ClipConvex( parentPlane.getCenter(), side * parentPlane.getNormal(), poly )
            
            iParent = parentNode.getParentIndex()
            node = parentNode
        
        return poly