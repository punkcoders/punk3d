# api imports

import bpy
import sys
import os
import imp
import mathutils
from math import *

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )

sys.path.append( DIR + "/punkMap/src/maths" )

import PolyOp
imp.reload( PolyOp )
from PolyOp import *

# ----------------------------------------------------------------
# BSP OBJECTS ----------------------------------------------------
# ----------------------------------------------------------------

# the public static data lists

class BSP:
    
    PLANES = []
    NODES = []
    LEAVES = []
        
# plane
    
class BSP_plane:

    # build / delete
    
    def __init__( self, normal: tuple, offset: float ):
        
        self._normal = normal
        self._offset = offset
        self._iFaces = []

        
    def __del__( self ):
        
        del self._iFaces
        del self._normal
        del self._offset

        
    # getters
        
    def similarTo( self, plane2, epsilon ):
        
        ok = ( ( self._normal - plane2._normal ).length < epsilon )
                     
        if ok:
            
            ok = ( abs( self._offset - plane2._offset ) < epsilon ) 
        
        return ok
    
    def getCenter( self ):
        
        return self._offset * self._normal
    
    def getNormal( self ):
        
        return self._normal
    
    def getFaceIndexes( self ):
        
        return self._iFaces
    
    # setters
    
    def addFaceIndex(self, iFace: int ):
        
        new = True
        for i in self._iFaces:
            if i == iFace:
                new = False
                break
        if new:
            self._iFaces.append( iFace )                
        
    # trace
    
    def __str__(self):
        
        s = "Plane: "
        s += "faces: "
        s += str( self._iFaces )
        return s        
    
    # point side
    
    def pointSide( self, point: object, epsilon: float ) -> bool:
        
        return ( ( (point @ self._normal) - self._offset ) >= epsilon )


# node        
        
class BSP_node:

    # build / delete
        
    def __init__( self, iPlane: int, iParent: int, frontOfParent: bool ):
    
        self._iPlane = iPlane
        self._iParent = iParent
        self._frontOfParent = frontOfParent
        self._iChildren = [-1,-1]

        
    def __del__( self ):
        
        del self._iChildren
        
        
    # getters / setters

    def getParentIndex( self )->int:
        
        return self._iParent

    def getPlaneIndex( self )->int:
        
        return self._iPlane

    def isFrontOfPArent( self )->bool:
        
        return self._frontOfParent

    def getBackChild( self )->int:
        
        return self._iChildren[0]
        
    def getFrontChild( self )->int:
        
        return self._iChildren[1]
        
    def setBackChild( self, index:int ):
        
        self._iChildren[0] = index
        
    def setFrontChild( self, index:int ):
        
        self._iChildren[1] = index

    # tracer
    
    def __str__( self )->str:
    
        s = "node "
        s += "plane: " + str( self._iPlane ) + ", "
        s += "parent: " + str( self._iParent ) + ", "
        s += "front_of_parent: " + str( self._frontOfParent ) + ", "
        s += "children: " + str( self._iChildren )
        return s 


# leaf

class BSP_leaf:
    
    # build / delete
    
    def __init__( self ):
    
        self._occluder = False
        self._faces = []
     
        
    def __del__( self ):
        
        del self._faces
     
    # getter / setters
        
    def addFace( self, face: object ):
    
        self._faces.append( face )      
        
    def getFaces( self )->list:
        
        return self._faces
    
    def setOccluder( self ):
        
        self._occluder = True
        
    def isOccluder( self )->bool:
        
        return self._occluder
    
    # tracer
    
    def __str__( self ):
        
        s = "leaf "
        s = "occluder: " + str( self._occluder )        
        return s
    
        
# leaf face

class BSP_leafFace:
    
    
    def __init__( self, verts: list, normal: tuple, iNode: int ):
    
        self._verts = verts
        self._normal = normal
        self._iNode = iNode
        
        
    def __del__( self ):
    
        del self._verts
        del self._normal
        
        
    def getVerts( self ):
    
        return self._verts
    
    
    def getNormal( self ):
    
        return self._normal
    
    
    def getIndexNode( self ):
    
        return self._indexNode
    

# ----------------------------------------------------------------
# STATIC CLASS FOR BSP NODES BUILD -------------------------------
# ----------------------------------------------------------------        
        
class BSP_Builder:
                
    # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   
    # THE ITERATIVE METHOD
    # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----
    
    def __InsertFaces( iParent: int, frontOfParent: bool, iFaces: list, allFaces: list, facesPlane: list )->list:
        
        # list planes containing faces
        
        iPlanes = []
        for iFace in iFaces:
            iPlane1 = facesPlane[ iFace ]
            new = True
            for iPlane2 in iPlanes:
                if iPlane1 == iPlane2:
                    new = False
                    break
            if new:
                iPlanes.append( iPlane1 )
        
        
        # back / front test to select the plane with the best balancing
        # this part is the most cpu-intensive of bsp building
        
        maxBalance = len( iFaces )
        iPlaneFound = -1
        
        for iPlane in iPlanes:
            
            plane = BSP.PLANES[ iPlane ]
            balance = 0
            
            for iFace in iFaces :
                
                face = allFaces[iFace]
                
                back = 0
                front = 0
            
                for vert in face:
                    if not plane.pointSide( vert, -0.0001 ):
                        back = 1
                    if plane.pointSide( vert, 0.0001 ):
                        front = 1
                        
                balance = balance - back + front
                
            balance = abs( balance )
            if balance < maxBalance:
                iPlaneFound = iPlane
                maxBalance = balance
                        
                        
        # index plane found ! create the node and store child index in parent
        
        #print( "plane selected: " + str( iPlaneFound ) )
        
        node = BSP_node( iPlaneFound, iParent, frontOfParent )
        iNode = len( BSP.NODES )
        
        if iParent > -1 :
            parentNode = BSP.NODES[ iParent ]
            if frontOfParent :
                parentNode.setFrontChild( iNode )
            else :
                parentNode.setBackChild( iNode )
                
        BSP.NODES.append( node )
        
        
        # re-create iFaceList eliminating plane faces
        
        plane = BSP.PLANES[ iPlaneFound ]
        
        newFaces = []
        planeFaces = plane.getFaceIndexes()
        for iFace1 in iFaces:
            keep = True
            for iFace2 in planeFaces:
                if iFace1 == iFace2 :
                    keep = False
                    #print( "remove face " + str( iFace1 ) )
                    break
            if keep :
                newFaces.append( iFace1 )
        
        
        # back / front balanced indexFace lists for recursion-iteration        
        
        backFaces = []
        frontFaces = []
        
        for iFace in newFaces :
                
            face = allFaces[iFace]
                
            back = False
            front = False
            
            for vert in face:
                if not plane.pointSide( vert, -0.0001 ):
                    back = True
                if plane.pointSide( vert, 0.0001 ):
                    front = True
                        
            if back:
                backFaces.append( iFace )
                    
            if front:
                frontFaces.append( iFace )
                
        #print( "balance for node " + str( iNode ) + " : " + str( len(backFaces) ) + " / " + str( len(frontFaces) ) )
                    
        
        # for this two new lists, iterate
        # iParent: int, frontOfParent: bool, iFaces: list, allFaces: list, facesPlane: list
        
        newArgsList = []
        
        if len( backFaces ) > 0 :
            newArgsList.append( [ iNode, False, backFaces ] )
            
        if len( frontFaces ) > 0 :
            newArgsList.append( [ iNode, True, frontFaces ] )
        
        return newArgsList
                
    
    # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   
    # BUILD NODES
    # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----     
    
    def BuildNodesFromFaces( faces: list ) -> bool:
        
        print( "### BSP NODES ENCODING ###" )
        
        if len( faces ) == 0 :
            
            print( "ERROR: FACE LIST EMPTY" )
            return False
        
        # caching
        
        V = mathutils.Vector
        
        # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   
        # 1/ make the plane-faces groups
        # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   
        
        time.sleep(.5)    
        gc.collect()        
        print( "# 1 - GROUP LEAVES BY PLANES AND SORT PLANES BY NUMBER OF LEAVES" )
        
        # start stupidly with one face <-> one plane
        
        planes = []
        
        iFace = 0
        for face in faces:
            
            # FOUTRE CE BORDEL DANS POLYOP
            
            # compute center
            
            center = V((0,0,0))            
            for vert in face:                
                center += vert
            center /= len( face )
            
            # compute average normal (don't use bmesh one)
            
            normals = []
            v1 = face[ len(face)-1 ]
            for v2 in face:
                normal = (v1-center).cross(v2-center)
                normal.normalize()
                normals.append(normal)
                v1 = v2
            normal = V((0,0,0))
            for no2 in normals:
                normal += no2
            normal /= len( normals )
            normal.normalize()
            
            # store plane
            
            plane = BSP_plane( normal, center @ normal )
            planes.append( plane )
        
            iFace += 1

         
        # brute force test to eliminate redundant planes and store faces in planes  
        
        lastList = planes
        
        iFace1 = 0
        for plane1 in lastList:
            
            plane1.addFaceIndex( iFace1 )
            
            new = True            
            iFace2 = 0
            for plane2 in BSP.PLANES:     
                
                if iFace1 != iFace2:  
                          
                    if plane1.similarTo(plane2,0.0001):                   
                        new = False
                        plane2.addFaceIndex( iFace1 )
                        
                iFace2 += 1 
                
            if new:
                BSP.PLANES.append( plane1 )                    
                               
            iFace1 += 1
                
        print( "faces: "+ str(len(lastList)) )
        print( "planes: "+ str(len(BSP.PLANES)) )
                
        del lastList
        del planes
        
        # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   
        # 2/ recursive balanced BSP build
        # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----         
        
        print( "# 2 - BUILDING BSP NODES (this is the critical step)" ) # we may add other sorting keys
            
        # create bijections faces->planes
        
        facesPlane = []
        while len(facesPlane) < len(faces):
            facesPlane.append(-1)
                
        iPlane = 0
        for plane in BSP.PLANES:            
            for iFace in plane.getFaceIndexes():
                facesPlane[ iFace ] = iPlane            
            iPlane += 1
            
            
        # the iterative building
        
        insF = BSP_Builder.__InsertFaces # cache method       
                        
        iFaces = []
        while len( iFaces ) < len(faces):            
            iFace = len( iFaces )
            iFaces.append( iFace )
        
        pile = [ [ -1, False, iFaces ] ]
        
        while len( pile ):
            
            newPile = []
            
            for args in pile:
                
                newArgsList = insF( args[0], args[1], args[2], faces, facesPlane )
                for newArgs in newArgsList:
                    newPile.append( newArgs )
                    
            pile = newPile
            del newPile
           
        
        # BSP is built
        
        print( "### BSP NODES BUILT ###" )
        
        return True



    # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   
    # BUILD LEAVES
    # ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----   ---- ---- ---- ----

    def BuildLeaves():
        
        for node in BSP.NODES :
            
            if node.getBackChild() == -1 :
                
                node.setBackChild( - 1 - len(BSP.LEAVES) )
                BSP.LEAVES.append( BSP_leaf() )
             
                
            if node.getFrontChild() == -1 :
                
                node.setFrontChild( - 1 - len(BSP.LEAVES) )
                BSP.LEAVES.append( BSP_leaf() )
                
        
        print( "### BSP LEAVES BUILT ###" )