import mathutils
from math import *

class PolyOp:

    # -------------------------------------------------------------------------
    # static props
    # -------------------------------------------------------------------------
    
    Isec: object = mathutils.geometry.intersect_line_plane
    
    # -------------------------------------------------------------------------
    # static methods
    # -------------------------------------------------------------------------
    
    # check if face is convex
    
    def IsFacePlanar( verts: list, epsilon: float )->bool:
    
        res = PolyOp.GetFaceCenterAndNormal( verts )
        center = res[ 0 ]
        averageNormal = res[ 1 ]
        
        length = 0        
        v1 = verts[ len(verts)-1 ]
        for v2 in verts:
            normal = (v1-center).cross(v2-center)
            normal.normalize()
            length += (normal-averageNormal).length
            v1 = v2
        length /= len( verts )
            
        return ( length < epsilon )
    
    
    # generate face center & normal
    
    def GetFaceCenterAndNormal( verts: list )->list:
        
        V = mathutils.Vector
        
        # compute barycenter
            
        center = V((0,0,0))            
        for vert in verts:                
            center += vert
        center /= len( verts )
            
        # compute average normal (don't use bmesh one)
            
        normals = []
        v1 = verts[ len(verts)-1 ]
        for v2 in verts:
            normal = (v1-center).cross(v2-center)
            normal.normalize()
            normals.append(normal)
            v1 = v2
                
        normal = V((0,0,0))
        for no2 in normals:
            normal += no2
        normal /= len( normals )
        normal.normalize()
        
        # end
        
        return [ center, normal ]
            
    
    # generate a square from a plane
    
    def SquareFromPlane( center: object, normal: object, sz: float )->list:
        
        normal.normalize()
        vi = normal.orthogonal()
        vi.normalize()
        vj = normal.cross( vi )
        
        return [ center -sz*vi -sz*vj, center +sz*vi -sz*vj, center +sz*vi +sz*vj, center -sz*vi +sz*vj ]
    
    
    # clipping and splitting ( point - center ) @ normal
    
    def ClipConvex( center: object, normal: object, verts: list )->list:
        
        newVerts = []
        
        if len(verts) == 0:
            return newVerts
        
        lastVert = verts[ len(verts)-1 ]
        lastSide = ( ( lastVert - center ) @ normal >= 0 )
        
        for newVert in verts :
            
            if lastSide:
                
                newVerts.append( lastVert )   
                         
            newSide = ( ( newVert - center ) @ normal >= 0 )
            
            if newSide != lastSide :
                                
                isec = PolyOp.Isec( lastVert, newVert, center, normal, False )
                if isec != None:
                    newVerts.append( isec )                
                lastSide = newSide   
                    
            lastVert = newVert            
            
        return newVerts
    
    
    def SplitConvex( center: object, normal: object, verts: list )->list:
        
        backVerts = []
        frontVerts = []
        
        if len(verts) == 0:
            return [backVerts,frontVerts]
        
        lastVert = verts[ len(verts)-1 ]
        lastSide = ( ( lastVert - center ) @ normal >= 0 )
        
        for newVert in verts :
            
            if lastSide:
                
                frontVerts.append( lastVert )   
                
            else :
                
                backVerts.append( lastVert )
                         
            newSide = ( ( newVert - center ) @ normal >= 0 )
            
            if newSide != lastSide :
                                
                isec = PolyOp.Isec( lastVert, newVert, center, normal, False )
                if isec != None:
                    newVerts.append( isec ) 
                    backVerts.append( isec )                
                frontVerts.append( isec )
                lastSide = newSide   
                    
            lastVert = newVert            
            
        return [backVerts,frontVerts]
    
        
    # generate a polygon defined by a plane and a centered square box
        
    def PolyFromPlane( center: object, normal: object, sz: float )->list:
            
        V = mathutils.Vector
            
        verts = PolyOp.SquareFromPlane( center, normal, sz*2 )
            
        verts = PolyOp.ClipConvex( V((-sz,  0,  0)) , V((  1,  0,  0)), verts )
        verts = PolyOp.ClipConvex( V(( sz,  0,  0)) , V(( -1,  0,  0)), verts )
            
        verts = PolyOp.ClipConvex( V((  0,-sz,  0)) , V((  0,  1,  0)), verts )
        verts = PolyOp.ClipConvex( V((  0, sz,  0)) , V((  0, -1,  0)), verts )
            
        verts = PolyOp.ClipConvex( V((  0,  0,-sz)) , V((  0,  0,  1)), verts )
        verts = PolyOp.ClipConvex( V((  0,  0, sz)) , V((  0,  0, -1)), verts )
            
        return verts
    
    
    # generate a bounding box from a vertex list
    
    def BBoxFromVerts( verts: list )->list:
        
        v = verts[0]
        bbox = [ [v[0],v[1],v[2]] , [v[0],v[1],v[2]] ]
        
        for vert in verts :
            
            for dim in [0,1,2] :
                
                if vert[dim] < bbox[0][dim]:
                    
                    bbox[0][dim] = vert[dim]
                    
                elif vert[dim] > bbox[1][dim]:
                    
                    bbox[1][dim] = vert[dim]
                    
        return BBox
    
            
# test

