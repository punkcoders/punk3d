# system imports

import bpy
import sys
import os
import imp
import mathutils
from math import *

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )

sys.path.append( DIR + "/punkMap/src/maths" )

import PolyOp
imp.reload( PolyOp )
from PolyOp import *


# DATA LISTS

class CVX:
    
    CONVEXES = []
    PLANES = []
    FACES = []
    VERTS = []


# Convex class

class Convex:
    
    # build / delete
    
    def __init__( self, firstFace: int, numFaces: int, occluder: bool ):
        
        self._firstFace = firstFace
        self._numFaces = numFaces
        self._occluder = occluder
        
    # getters
    
    def getFirstFace( self )->int:
        
        return self._firstFace
    
    def getNumFaces( self )->int:
        
        return self._numFaces
    
    def getOccluder( self )->bool:
        
        return self._occluder
        
    # trace
    
    def __str__( self ):
        
        s = ""
        s += "Convex "
        s += "face: " + str( self._firstFace ) + " to " + str( self._firstFace + self._numFaces - 1 ) + " "
        s += "occludes: " + str( self._occluder )
        return s
    
    
# convex planes

class ConvexPlane:
    
    # build / delete
    
    def __init__( self, normal: object, offset: float, faces: list ):
        
        self._normal = normal
        self._offset = offset
        self._iFaces = faces
        
    def __del__( self ):
        
        del self._iFaces

        
    # getters / setters
    
    def getOffset( self ):
        
        return self._offset
    
    def getCenter( self ):
        
        return self._offset * self._normal
    
    def getNormal( self ):
        
        return self._normal
    
    def getFaceIndexes( self ):
        
        return self._iFaces  
    
    def addFace( self, iFace ):
        
        self._iFaces.append( iFace )          
        
    # trace
    
    def __str__(self):
        
        s = "Plane "
        s += "normal: " + str( self._normal ) + " "
        s += "offset: " + str( self._offset ) + " "
        s += "faces: " + str( self._iFaces ) + " "      
        return s        
    
    # other
    
    def similarTo( self, plane2, epsilon ):
        
        if ( self._normal - plane2._normal ).length < epsilon :
            return abs( self._offset - plane2._offset ) < epsilon
            
        return False


# convex faces

class ConvexFace:
    
    # build / delete
    
    def __init__( self, vertsIndexes: list ):
        
        self._vertsIndexes = vertsIndexes    
        self._iPlane = -1
        
    def __del__( self ):
        
        del self._vertsIndexes
        
    # getters / setters
    
    def getPlane( self )->int:
        
        return self._iPlane
    
    def setPlane( self, indexPlane: int ):
        
        self._iPlane = indexPlane
        
    def getVertsIndexes( self ):
        
        return self._vertsIndexes
    
    def getVerts( self ):
        
        ips = self._vertsIndexes
        poly = []
        for ip in ips :
            poly.append( CVX.VERTS[ ip ] )
            
        return poly
    
    def addVert( self, iVert ):
        
        self._vertsIndexes.append( iVert ) 
        
    
    # trace
    
    def __str__( self ):
        
        s =  "ConvexFace: "
        s += "verts: " + str( self._vertsIndexes ) + " "
        s += "plane: " + str( self._iPlane )
        return s
        
        
# computations here

class ConvexManager:
    
    def BuildConvexes( convexes: list, epsilonPlanes: float ):

        V = mathutils.Vector

        # store convex data without planes
            
        for convexData in convexes:
            
            convexVerts = convexData['verts']
            convexFaces = convexData['faces']
            convexOccluder = convexData['occluder']
            
            # store verts
            
            convexFirstVert = len( CVX.VERTS )
            for vert in convexVerts :
                CVX.VERTS.append( vert )
                
            # store faces
            
            convexFirstFace = len( CVX.FACES )
            for face in convexFaces :
                absIps = []
                for ip in face :
                    absIps.append( ip + convexFirstVert )
                CVX.FACES.append( ConvexFace( absIps ) )
                
            # store convex
            
            CVX.CONVEXES.append( Convex( convexFirstFace, len(convexFaces), convexOccluder ) )
                            
        
        # first, make 1 plane per face
        
        FCN = PolyOp.GetFaceCenterAndNormal
        facePlanes = []
        iFace = 0
        for face in CVX.FACES :
            data = FCN( face.getVerts() )
            plane = ConvexPlane( data[1], data[0] @ data[1], [iFace] )
            facePlanes.append( plane )
            iFace += 1        
        
        # group similar planes
        
        planeGroups = []
        
        for plane1 in facePlanes :
            
            addedToGroup = False
            
            for group in planeGroups :               
                if len( group ) :                    
                    plane2 = group[0]                    
                    if plane1.similarTo( plane2, epsilonPlanes ) :                        
                        group.append( plane1 )
                        addedToGroup = True                       
                        
            if not addedToGroup :       
                planeGroups.append( [ plane1 ] )
        
        del facePlanes        
        
        # convert groups to average planes with faces indexes
        
        unsortedPlanes = []
        
        for group in planeGroups :
            
            averageNormal = V((0,0,0))
            averageOffset = 0
            faces = []
            
            for plane in group :
                
                averageNormal += plane.getNormal()
                averageOffset += plane.getOffset()
                faces.append( plane.getFaceIndexes()[0] )
                
            averageNormal.normalize()
            averageOffset /= len( group )
            
            unsortedPlanes.append( ConvexPlane( averageNormal, averageOffset, faces ) )
            
            
        # sort planes by number of faces
        
        while len( unsortedPlanes ) :
            
            iPlaneFound = -1
            maxFaces = 0
            
            iPlane = 0
            for plane in unsortedPlanes :
                
                nFaces = len( plane.getFaceIndexes() )
                if nFaces > maxFaces :                    
                    maxFaces = nFaces
                    iPlaneFound = iPlane
        
                iPlane += 1
                
            CVX.PLANES.append( unsortedPlanes[ iPlaneFound ] )
            del unsortedPlanes[ iPlaneFound ]
            
            
        # store bijections face -> plane
        
        iPlane = 0
        for plane in CVX.PLANES :
            
            iFaces = plane.getFaceIndexes()            
            for iF in iFaces :                
                CVX.FACES[ iF ].setPlane( iPlane )
                
            iPlane += 1
                
                
        # refine faces verts to make them the nearest possible of plane
        
        for face in CVX.FACES :
            
            plane = CVX.PLANES[ face.getPlane() ]
            normal = plane.getNormal()
            offset = plane.getOffset()
            
            ips = face.getVertsIndexes()
            
            for ip in ips :
                
                vert = CVX.VERTS[ ip ]                
                d = vert @ normal - offset                
                vert -= d * normal               
                CVX.VERTS[ ip ] = vert
                
        
        return True