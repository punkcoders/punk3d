# api imports

import bpy
import sys
import os
import imp
import bmesh
import mathutils
from math import *

# custom imports

DIR = os.path.dirname( bpy.data.filepath )
if not DIR in sys.path:
    sys.path.append( dir )

sys.path.append( DIR + "/punkMap/src/maths" )

import PolyOp
imp.reload( PolyOp )
from PolyOp import *

import Convex
imp.reload( Convex )
from Convex import *


# static class extracting a list of Convex objects

class ConvexExtractor:
    
    # ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
    # control the scene before conversion
    # ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
    
    def MeshesAreConvex( epsilon )->bool:
        
        # list all scene mesh objects

        meshObj = []
        for obj in bpy.data.objects:
            if obj.type == "MESH":
                meshObj.append( obj )
                
                
        # check if all faces are convex
        
        validScene = True
        
        for obj in meshObj:
            
            validMesh = True
            
            polys = obj.data.polygons
            verts = obj.data.vertices
            
            for poly in polys:
                
                ips = poly.vertices
                
                # generate plane
                
                faceVerts = []
                for i in ips:
                    faceVerts.append( verts[i].co )
                    
                if not PolyOp.IsFacePlanar( faceVerts, .0001 ):
                    validScene = False
                    validMesh = False
        
            if not validMesh:
                    break # no need to test more faces
                
        if not validMesh:
            print( 'MODELING ERROR: "' + str( obj.name ) + '" has non-planar faces' )
                
        if not validScene:
            return False
            
        
        # check if all meshes are convex
        
        validScene = True
        
        for obj in meshObj:
            
            validMesh = True
            
            polys = obj.data.polygons
            verts = obj.data.vertices
            
            for poly in polys:
                
                ips = poly.vertices
                
                # generate plane
                
                faceVerts = []
                for i in ips:
                    faceVerts.append( verts[i].co )                
                res = PolyOp.GetFaceCenterAndNormal( faceVerts )                
                center = res[0]
                normal = res[1]
                offset = center @ normal
            
                # test if other verts are back to plane
                
                iVert = 0
                for v in verts:
                    
                    # eliminate face verts
                    
                    inFace = False
                    for i in ips:
                        if iVert == i:
                            inFace = True
                            break # no need to test more points
                        
                    # front plane test
                        
                    if inFace == False:
                        if ( verts[iVert].co @ normal ) - offset >= -epsilon:
                            validScene = False
                            validMesh = False
                            break # no need to test more points
                    
                    iVert += 1
                
                if not validMesh:
                    break # no need to test more faces
                
            if not validMesh:
                print( 'MODELING ERROR: "' + str( obj ) + '" is not convex, closed, without coplanar faces' )
        
        return validScene
            
    
    
    # ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
    # conversion to convex data
    # ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- ---- 
    
    def ConvertSceneToConvex()->bool:
                
        V = mathutils.Vector
                
                
        # list all scene mesh objects

        meshObj = []
        for obj in bpy.data.objects:
            if obj.type == "MESH":
                meshObj.append( obj )

        numConvexes = len( meshObj )
        

        # loop for every object to extract vectors, faces and boolean occlusion

        convexes = []
        
        for obj in meshObj:
    
            # check if convex is occluder or transparent
    
            occluder = True
            if len( obj.data.materials ):
                for material in obj.data.materials:
                    if obj.data.materials[0].diffuse_color[3] < 1 :
                        #transparency detected
                        occluder = False
                
            # extract mesh geometry
            
            mat = obj.matrix_world
            polys = obj.data.polygons
            verts = obj.data.vertices
            
            absVerts = []
            for vert in verts:
                absVerts.append( mat @ vert.co )
            
            polysIps = []
            for poly in polys:
                ips = poly.vertices
                polyIps = []
                for ip in ips:
                    polyIps.append( ip )
                polysIps.append( polyIps )
        
            # store in tables
        
            convexes.append( { 'verts': absVerts, 'faces': polysIps, 'occluder': occluder } )            
            
        return convexes