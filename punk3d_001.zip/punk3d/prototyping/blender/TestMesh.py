import bpy
 
# delete mesh function found on the internet

def deleteMesh ( mesh ):
    
    # Extra test because this can crash Blender.
    try:
        mesh.user_clear()
        can_continue = True
    except:
        can_continue = False
    
    if can_continue == True:
        try:
            bpy.data.meshes.remove(mesh)
            result = True
        except:
            result = False
    else:
        result = False
        
    return result


# delete objects if needed

if "tracerColl" in bpy.data.collections:
    coll = bpy.data.collections["tracerColl"]
    for obj in coll.objects:
        bpy.data.objects.remove(obj, do_unlink=True)
    bpy.data.collections.remove( coll )
    
if "tracerObj" in bpy.data.objects:
    bpy.data.objects["tracerObj"].delete()

if "tracer" in bpy.data.meshes:
    deleteMesh( bpy.data.meshes["tracer"] )
    

# create mesh

verts = [ (-1,-1,0) , (-1,1,0) , (1,1,0) , (1,-1,0) ]
edges = []
ngons = [ [0,1,2,3] ]
tracer = bpy.data.meshes.new("tracer")
tracer.from_pydata( verts, edges, ngons )
tracer.update()


# create object & collection

tracerObj = bpy.data.objects.new( "tracerObj", tracer )
tracerColl = bpy.data.collections.new( "tracerColl" )
bpy.context.scene.collection.children.link( tracerColl )
tracerColl.objects.link( tracerObj )